// JavaScript Document
function myNav() {
    document.getElementById("nav").innerHTML = "Portfolio";
}

function myLinks() {
    var x = document.getElementsByTagName("li");
    document.getElementById("link").innerHTML = x.length;
}

function myDiv() {
    var para = document.createElement("P");
    var t = document.createTextNode("Painting, Graphic Design, Illustration, and Tees");
    para.appendChild(t);
    document.getElementById("myDIV").appendChild(para);
}
//use this code as is:

function getCookie(c_name)
{
var i,x,y,ARRcookies=document.cookie.split(";");
for (i=0;i<ARRcookies.length;i++)
  {
  x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
  y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
  x=x.replace(/^\s+|\s+$/g,"");
  if (x==c_name)
    {
    return unescape(y);
    }
  }
}





// this code puts creates a cookie or changes a cookie.  Use this AS...no need to change it.



function setCookie(c_name,value,exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
document.cookie=c_name + "=" + c_value;
}



//deal with the information inside of the cookie...This you will need to alter

function checkCookie()
{
var username=getCookie("test3");
if (username!=null && username!="")
  {
  alert("Welcome again " + username);
  }
else
  {
  username=prompt("Please enter your name:","");
  if (username!=null && username!="")
    {
    setCookie("test3",username,30);
    }
  }
}

//Delete cookie

function removeCookie() {
    setCookie("test3","",-1);
}


	
	
	
